package com.Govt.funded.Training.Centers.Service;


import com.Govt.funded.Training.Centers.Entity.TrainingCenter;
import com.Govt.funded.Training.Centers.Repository.TrainingCenterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TrainingCenterService {

    @Autowired
    private TrainingCenterRepository trainingCenterRepository;

    public TrainingCenter saveTrainingCenter(TrainingCenter trainingCenter) {
        // Assuming you have a method to generate the createdOn timestamp
        trainingCenter.setCreatedOn(System.currentTimeMillis());


        // Save the TrainingCenter entity
        return trainingCenterRepository.save(trainingCenter);
    }

    public List<TrainingCenter> getAllTrainingCenters() {
        return trainingCenterRepository.findAll();
    }
}
