package com.Govt.funded.Training.Centers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GovtFundedTrainingCentersApplication {

	public static void main(String[] args) {
		SpringApplication.run(GovtFundedTrainingCentersApplication.class, args);
	}

}
