package com.Govt.funded.Training.Centers.Controller;




import com.Govt.funded.Training.Centers.Entity.TrainingCenter;
import com.Govt.funded.Training.Centers.Repository.TrainingCenterRepository;
import com.Govt.funded.Training.Centers.Service.TrainingCenterService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/training")
public class TrainingCenterController {

    private TrainingCenterService trainingCenterService;
    private TrainingCenterRepository trainingCenterRepository;

    public TrainingCenterController(TrainingCenterService trainingCenterService, TrainingCenterRepository trainingCenterRepository) {
        this.trainingCenterService = trainingCenterService;
        this.trainingCenterRepository = trainingCenterRepository;
    }

    @PostMapping("/training-centers")
    public ResponseEntity<TrainingCenter> createTrainingCenter(@Valid @RequestBody TrainingCenter trainingCenter) {
        // Populate createdOn with server timestamp
        trainingCenter.setCreatedOn(System.currentTimeMillis());
        // Save the training center to database (implementation not shown)

        TrainingCenter trainingCenter1 = trainingCenterService.saveTrainingCenter(trainingCenter);
        // Return the saved training center in JSON format
        return new ResponseEntity<>(trainingCenter1, HttpStatus.CREATED);
    }


    @GetMapping("/View-All-TrainingCenter")
    public ResponseEntity<List<TrainingCenter>> getAllTrainingCenters() {
        List<TrainingCenter> trainingCenters = trainingCenterService.getAllTrainingCenters();
        if (trainingCenters != null && !trainingCenters.isEmpty()) {
            return new ResponseEntity<>(trainingCenters, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    // Exception handler for validation errors
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public String handleValidationExceptions(MethodArgumentNotValidException ex) {
        StringBuilder errors = new StringBuilder();
        ex.getBindingResult().getFieldErrors().forEach(error -> {
            errors.append(error.getDefaultMessage()).append("; ");
        });
        return errors.toString();
    }

    @GetMapping("/ViewTrainingCenter/{centerID}")

    public ResponseEntity<?> getTrainingCenter(@PathVariable Long centerID) {

        Optional<TrainingCenter> byId = trainingCenterRepository.findById(centerID);
        if (byId.isPresent()) {
            TrainingCenter trainingCenter = byId.get();

            return new ResponseEntity<>(trainingCenter, HttpStatus.OK);

        } else {
            return new ResponseEntity<>("Training center is empty ", HttpStatus.BAD_REQUEST);
        }


    }


}



