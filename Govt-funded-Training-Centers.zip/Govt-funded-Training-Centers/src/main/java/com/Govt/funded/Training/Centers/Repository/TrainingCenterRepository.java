package com.Govt.funded.Training.Centers.Repository;


import com.Govt.funded.Training.Centers.Entity.TrainingCenter;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TrainingCenterRepository extends JpaRepository<TrainingCenter, Long> {
}