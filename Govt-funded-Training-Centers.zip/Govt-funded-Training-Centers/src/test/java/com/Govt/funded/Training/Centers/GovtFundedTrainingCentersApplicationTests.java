package com.Govt.funded.Training.Centers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GovtFundedTrainingCentersApplicationTests {

	@Test
	void contextLoads() {
	}

}
